controlling a ws2801 LED stripe
  start scratch with 
    scratch ~/scratchClient/scratch/ws2801.sb
  
  start scratchClient with
  
    cd ~/scratchClient
    sudo python src/scratchClient -config scratch/ws2801/config_spi_ws2801.xml