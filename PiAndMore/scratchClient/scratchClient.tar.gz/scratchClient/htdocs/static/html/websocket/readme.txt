html pages for adapter 'websocket'

see adapter.websocket.WebsocketXY_Adapter
see config/config_websocket_pendel.xml